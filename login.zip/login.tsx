import { Icon } from "@iconify/react";

export function Login() {
  return (
    <main className="min-h-screen bg-background text-foreground flex flex-col items-center px-6 py-10 sm:py-14">
      <section className="w-full max-w-sm flex-1 flex flex-col justify-center">
        <header className="text-center mb-9">
          <div className="mx-auto mb-5 size-16 rounded-2xl bg-primary flex items-center justify-center">
            <Icon icon="ph:handshake" className="size-8 text-primary-foreground" />
          </div>
          <h1 className="font-heading text-[30px] leading-tight font-bold tracking-[-0.03em]">
            Extra İşler
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">Hesabınıza giriş yapın</p>
        </header>
        <form className="space-y-4" action="#" method="post">
          <div>
            <label htmlFor="email" className="sr-only">
              Email
            </label>
            <input
              id="email"
              type="email"
              placeholder="Email"
              className="w-full h-14 rounded-2xl border border-border bg-input px-4 text-[15px] text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary transition"
            />
          </div>
          <div className="relative">
            <label htmlFor="password" className="sr-only">
              Şifre
            </label>
            <input
              id="password"
              type="password"
              placeholder="Şifre"
              className="w-full h-14 rounded-2xl border border-border bg-input px-4 pr-12 text-[15px] text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary transition"
            />
            <button
              type="button"
              aria-label="Şifreyi göster"
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition"
            >
              <Icon icon="ph:eye" className="size-5" />
            </button>
          </div>
          <div className="flex justify-end pt-0.5">
            <a href="#" className="text-[13px] font-semibold text-primary hover:underline">
              Şifremi Unuttum?
            </a>
          </div>
          <button
            type="submit"
            className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-semibold text-[15px] hover:opacity-95 transition"
          >
            Giriş Yap
          </button>
        </form>
        <div className="flex items-center gap-4 my-7">
          <div className="h-px flex-1 bg-border" />
          <span className="text-xs text-muted-foreground">veya</span>
          <div className="h-px flex-1 bg-border" />
        </div>
        <div className="space-y-3">
          <button
            type="button"
            className="w-full h-14 rounded-2xl border border-border bg-card text-card-foreground font-semibold text-[15px] flex items-center justify-center gap-3 hover:bg-secondary transition"
          >
            <Icon icon="logos:google-icon" className="size-5" />
            <span>Google ile Devam Et</span>
          </button>
          <button
            type="button"
            className="w-full h-14 rounded-2xl border border-border bg-card text-card-foreground font-semibold text-[15px] flex items-center justify-center gap-3 hover:bg-secondary transition"
          >
            <Icon icon="logos:apple" className="size-5 text-foreground" />
            <span>Apple ile Devam Et</span>
          </button>
        </div>
      </section>
      <footer className="pt-8 text-center text-sm text-muted-foreground">
        <span>Hesabınız yok mu? </span>
        <a href="#" className="font-bold text-primary hover:underline">
          Kayıt Ol
        </a>
      </footer>
    </main>
  );
}
